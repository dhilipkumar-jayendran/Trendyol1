package com.trendyol.qa.base;

import java.util.Properties;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.safari.SafariDriver;

import com.trendyol.qa.config.ConfigPropReader;

import io.github.bonigarcia.wdm.WebDriverManager;

public class BaseClass {
	public static WebDriver driver;
    public static Properties prop;
    public ConfigPropReader co;
   	
    public BaseClass()
	{
		prop = ConfigPropReader.initConfigProp();
	}	
	
	public static void initialization(){		
		String browserName = prop.getProperty("browser.name");		
		System.out.println("browser name is : " + browserName);
		
		switch (browserName.toLowerCase()) {
		case "chrome":
			ChromeOptions chromeOptions = new ChromeOptions();
			chromeOptions.addArguments("--disable-notifications");
			WebDriverManager.chromedriver().setup();
			driver = new ChromeDriver(chromeOptions);
			break;
		case "firefox":
			WebDriverManager.firefoxdriver().setup();
			driver = new FirefoxDriver();
			break;
		case "safari":
			driver = new SafariDriver();
			break;
		default:
			System.out.println("Please pass the correct browser name " + browserName);
			break;
		}		
		driver.get(prop.getProperty("app.url"));		
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		acceptAllCookies();
	}
	
	public boolean isElementPresent(WebElement webElelemnt) {
		try {
			webElelemnt.isEnabled();
			return true;
		}
		catch(NoSuchElementException e){
            return false;
        }
	}
	
	//Hover on element
	public void hoverElement(WebElement element) {
		Actions actions = new Actions(driver);
		actions.moveToElement(element).perform();		
	}	
	
	public static void acceptAllCookies() {
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		if(driver.findElement(By.id("onetrust-accept-btn-handler")).isEnabled()){
			driver.findElement(By.id("onetrust-accept-btn-handler")).click();				
		}
	}
	
}
