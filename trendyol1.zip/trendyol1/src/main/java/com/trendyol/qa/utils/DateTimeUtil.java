package com.trendyol.qa.utils;

import java.util.Calendar;
import java.util.Date;

public class DateTimeUtil {
	
	
	public static String getSystemTime(){
	    Calendar cal = Calendar.getInstance();
	    Date time = cal.getTime();
	    String timestamp = time.toString();
	    System.out.println(timestamp);
	    String systime = timestamp.replace(":", "-");
	    System.out.println(systime);
	    return systime;
	}

}
