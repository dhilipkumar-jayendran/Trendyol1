package com.trendyol.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.trendyol.qa.base.BaseClass;

public class TrendyolLandingPage extends BaseClass {

	// PageFactory or Object Repository
	@FindBy(xpath = "//div[@class='link account-user']/p[@class='link-text']")
	WebElement lnkLogin;

	@FindBy(xpath = "//a[@class='close-button']")
	WebElement iconClose;

	// Initialize the page object
	public TrendyolLandingPage() {
		PageFactory.initElements(driver, this);
	}

	// Actions
	public String getLandingPageTitle() {
		return driver.getTitle();
	}

	public void clickLogin() {
		if (isElementPresent(iconClose)) {
			iconClose.click();
		}
		lnkLogin.click();		
	}
}
