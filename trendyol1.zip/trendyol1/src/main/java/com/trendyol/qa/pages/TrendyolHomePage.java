package com.trendyol.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.trendyol.qa.base.BaseClass;

public class TrendyolHomePage extends BaseClass{	
	
	//PageFactory or Object Repository
	@FindBy(xpath="//div[@class='account-nav-item user-login-container']")
	WebElement lnkUserDropdown;
	
	@FindBy(xpath="//p[@class='user-name']") 
	WebElement lnkUserName;
	
	//Initialize the page object
	public TrendyolHomePage() {
		PageFactory.initElements(driver, this);
	}
	
	//Actions
	public String getHomePageTitle() {
		return driver.getTitle();
	}
	
	public String getUserName() {			
		try {
			Thread.sleep(10000);
			hoverElement(lnkUserDropdown);			
		} catch (InterruptedException e) {			
			e.printStackTrace();
		}		
		return lnkUserName.getText();
	}

}
