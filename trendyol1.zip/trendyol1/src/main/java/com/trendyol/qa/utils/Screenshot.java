package com.trendyol.qa.utils;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

public class Screenshot {
	
	public static String imgname = null;
		
	/*
     * Method to Capture Screenshot with TestName and Timestamp appended.
     */
	public static String takeScreenshot(WebDriver driver, String testcaseName) throws IOException {
		
		String dateName = DateTimeUtil.getSystemTime();
		TakesScreenshot ts = ((TakesScreenshot) driver);
		File source = ts.getScreenshotAs(OutputType.FILE);
		String desination = System.getProperty("user.dir").concat("\\Screenshots\\" + testcaseName + dateName
				+ ".png");
		File finalDestination = new File(desination);
		FileUtils.copyFile(source, finalDestination);
		
		return desination;
	}	

}
