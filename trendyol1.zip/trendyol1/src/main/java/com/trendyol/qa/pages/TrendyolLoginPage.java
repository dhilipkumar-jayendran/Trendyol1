package com.trendyol.qa.pages;

import java.util.Properties;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.trendyol.qa.base.BaseClass;
import com.trendyol.qa.config.ConfigPropReader;

public class TrendyolLoginPage extends BaseClass{
	
	Properties prop;
	
	//PageFactory or Object Repository
	@FindBy(id="login-email") 
	WebElement TxtEmail;
	
	@FindBy(id="login-password-input")		
	WebElement TxtPassword;
	
	@FindBy(xpath="//button[@class='q-primary q-fluid q-button-medium q-button submit']") 
	WebElement BtnLogin;
	
	@FindBy(xpath="//div[@id='error-box-wrapper']/span[@class='message']") 
	WebElement lblLoginError;
	
	@FindBy(xpath="//button[@id='onetrust-accept-btn-handler']")
	WebElement btnAcceptCookies;
	
	//Initialize the page object
	public TrendyolLoginPage() {
		PageFactory.initElements(driver, this);
		prop = ConfigPropReader.initConfigProp();		
	}
	
	//Actions
	public String getLoginPageTitle() {
		return driver.getTitle();
	}
	
	public String getInvalidLoginErrorMsg() {
		return lblLoginError.getText();
	}
	
	public void setEmail(String username) {
		TxtEmail.clear();
		TxtEmail.sendKeys(username);
	}
	
	public void setPassword(String password) {
		TxtPassword.clear();
		TxtPassword.sendKeys(password);
	}
	
	public void clickLoginBtn() {
		BtnLogin.click();
	}
	
	public TrendyolHomePage loginToTrendyol(String username, String password) {				
		setEmail(username);		
		setPassword(password);		
		clickLoginBtn();		
		 
		return new TrendyolHomePage();
	}	
	
}
