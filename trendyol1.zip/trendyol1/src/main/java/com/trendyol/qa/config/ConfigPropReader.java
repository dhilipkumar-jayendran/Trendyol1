package com.trendyol.qa.config;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Properties;

public class ConfigPropReader {
	
	private static Properties prop;
	private static FileInputStream ip;
	
	public static Properties initLangProp(String language) {
		System.out.println("language is : " + language);
		
		prop = new Properties();
		try {
			switch (language.toLowerCase()) {
			case "english":
				ip = new FileInputStream("./src/main/resources/lang.en-EN.properties");
				break;
			case "french":
				ip = new FileInputStream("./src/main/resources/lang.de-DE.properties");
				break;				
				
			default:
				System.out.println("language not found : " + language);
				break;
			}
			prop.load(ip);
		} catch(Exception e) {			
		}
		return prop;
	}
	
	public static Properties initConfigProp() {
		try {
			prop = new Properties();
			FileInputStream stream = new FileInputStream("./src/main/resources/lang.de-DE.properties");
			InputStreamReader fis = new InputStreamReader(stream, "UTF-8");
			prop.load(fis);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop;
	}

}
