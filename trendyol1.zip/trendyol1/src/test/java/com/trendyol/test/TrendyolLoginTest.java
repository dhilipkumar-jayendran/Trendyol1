package com.trendyol.test;

import java.util.Properties;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.trendyol.qa.base.BaseClass;
import com.trendyol.qa.config.ConfigPropReader;
import com.trendyol.qa.pages.TrendyolHomePage;
import com.trendyol.qa.pages.TrendyolLandingPage;
import com.trendyol.qa.pages.TrendyolLoginPage;

public class TrendyolLoginTest extends BaseClass {

	TrendyolLandingPage tLandingPage;
	TrendyolLoginPage tLoginPage;
	TrendyolHomePage tHomePage;
	Properties prop;
	ExtentReports extent;
    ExtentTest test;

	public TrendyolLoginTest() {
		super();
	}

	@BeforeMethod
	public void setUp() {
		initialization();
		tLandingPage = new TrendyolLandingPage();
		tLoginPage = new TrendyolLoginPage();
		tHomePage = new TrendyolHomePage();
		prop = ConfigPropReader.initConfigProp();
	}	

	@Test(priority = 1)
	public void testLandingPageTitle() {
		Assert.assertEquals(tLandingPage.getLandingPageTitle(), prop.getProperty("landing.page.title"));		
	}

	@Test(priority = 2, enabled = false)
	public void testLoginPageTitle() {
		tLandingPage.clickLogin();
		Assert.assertEquals(tLoginPage.getLoginPageTitle(), prop.getProperty("login.page.title"));
	}

	@Test(priority = 3, enabled = false)
	public void testValidLoginCredentials() {
		tLandingPage.clickLogin();
		tHomePage = tLoginPage.loginToTrendyol(prop.getProperty("user.email"), prop.getProperty("user.password"));
		Assert.assertEquals(tHomePage.getUserName(), prop.getProperty("user.name"));
	}
	
	@Test(priority = 4, enabled = false)
	public void testInvalidUserNameLogin() {
		tLandingPage.clickLogin();
		tLoginPage.setEmail(prop.getProperty("invalid.user.email"));
		tLoginPage.setPassword(prop.getProperty("user.password"));
		tLoginPage.clickLoginBtn();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}		
		System.out.println(tLoginPage.getInvalidLoginErrorMsg());
		System.out.println(prop.getProperty("invalid.username.error.message"));
		Assert.assertEquals(tLoginPage.getInvalidLoginErrorMsg(), prop.getProperty("invalid.username.error.message"));
	}
	
	@Test(priority = 5)
	public void testInvalidPasswordLogin() {
		tLandingPage.clickLogin();
		tLoginPage.setEmail(prop.getProperty("user.email"));
		tLoginPage.setPassword(prop.getProperty("invalid.password.email"));
		tLoginPage.clickLoginBtn();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}	
		Assert.assertEquals(tLoginPage.getInvalidLoginErrorMsg(), prop.getProperty("invalid.password.error.message"));
	}
	
	@AfterMethod
    public void getResult(ITestResult result) {
		driver.quit();
    }
}
